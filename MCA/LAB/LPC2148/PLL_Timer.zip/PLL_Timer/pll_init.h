#ifndef _PLL_INIT_H_
#define _PLL_INIT_H_
void PLL_Config(void);
#endif
